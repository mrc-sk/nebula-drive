# ASS 面板

PHP 嵌入页面示例，声明文件放在 ASS/ 子目录

- 插件名：`ass-demo`
- 版本：`1.0.0`
- 协议：v2
- 运行时：`php`（要求 php>=7.4）
- 目录布局：`plugin.json` 与 `README.md` 在插件根目录；`register.go` / `co.BEGG` / 页面文件在 `ASS/` 子目录（宿主递归定位，深度 ≤ 5）

## 安装

1. 把整个目录解压到 `plugins/ass-demo/`。
2. 后台 → 插件 → 开启**全局总开关**（需勾选风险确认）。
3. 启用 `ass-demo`。

> 插件默认关闭，这是刻意设计。

## 页面

- `home`（main）→ in.php 
- `stats`（admin）→ stats.php 

> `home` 一律相对 **co.BEGG 所在目录**，不要写成 `ASS/in.php` 这种带子目录前缀的路径。

## 安全提醒

宿主对 `/ext/*` **完全透传鉴权**：不校验登录态、不注入 token、不设 iframe sandbox。
插件页面必须自己做权限校验。开启插件等同于把服务器执行权限交给插件作者。
