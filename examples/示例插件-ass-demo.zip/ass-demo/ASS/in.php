<?php
// 由 NebulaDrive 插件制作器生成。宿主下发的环境变量：
//   NB_PLUGIN_NAME / NB_PLUGIN_DIR / NB_PLUGIN_HOME / NB_PLUGIN_SITE_URL
//   NB_PLUGIN_PORT / NB_PLUGIN_HOST / NB_PLUGIN_PROTOCOL
// 注意：宿主对 /ext/* 完全透传鉴权，请在本文件里自己做权限校验。
$plugin = getenv('NB_PLUGIN_NAME') ?: 'ass-demo';
$site   = getenv('NB_PLUGIN_SITE_URL') ?: '';
?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ASS 面板</title>
<style>
  :root{--nebula-primary:#22d3ee;--nebula-accent:#0ea5e9;--line:#2a3560;--muted:#8d9cc4}
  *{box-sizing:border-box}
  body{margin:0;padding:22px 24px;background:#0f1630;color:#e6ecff;font:14px/1.6 -apple-system,BlinkMacSystemFont,'Segoe UI','Microsoft YaHei',sans-serif}
  h1,h2,h3{margin:0 0 8px}
  .widget{margin-bottom:12px}
  .pv-card{border:1px solid var(--line);border-radius:12px;padding:14px;background:#141d3c}
  .pv-stat{font-size:26px;font-weight:700;color:var(--nebula-primary)}
  .pv-btn{display:inline-block;padding:8px 16px;border-radius:9px;background:linear-gradient(135deg,var(--nebula-accent),#6366f1);color:#fff;font-size:12.5px;cursor:pointer;border:none}
  .pv-input{display:block;width:100%;max-width:300px;background:#0b1020;border:1px solid var(--line);border-radius:8px;padding:8px 11px;color:#e6ecff;font-size:12.5px}
  .pv-table{width:100%;border-collapse:collapse;font-size:12.5px}
  .pv-table td,.pv-table th{border:1px solid var(--line);padding:7px 10px;text-align:left}
  .pv-table th{color:var(--muted);background:#141d3c}
  .pv-alert{padding:10px 14px;border-radius:9px;background:#fbbf2415;border:1px solid #fbbf2455;color:#fbbf24;font-size:12.5px}
  .pv-divider{height:1px;background:var(--line);margin:14px 0}
</style>
</head>
<body>
      <div class="widget"><h2 style="font-size:20px">ASS 面板</h2><div style="color:var(--muted);font-size:12px">由可视化制作器生成</div></div>
      <div class="widget pv-card"><b style="font-size:13px">运行环境</b><div style="color:var(--muted);font-size:12px;margin-top:5px">PHP · 端口由宿主分配</div></div>
      <div class="widget"><div class="pv-stat">99</div><div style="color:var(--muted);font-size:11.5px">可用钩子</div></div>
      <div class="widget pv-alert">插件页面鉴权由插件自己负责，宿主完全透传。</div>
      <div class="widget"><span class="pv-btn">点我试试</span></div>
      <p style="color:var(--muted);font-size:11.5px;margin-top:18px">插件设置项：问候语 / 等级</p>
</body>
</html>