<?php
$port = getenv('NB_PLUGIN_PORT') ?: '0';
$name = getenv('NB_PLUGIN_NAME') ?: '';
$site = getenv('NB_PLUGIN_SITE_URL') ?: '';
?>
<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>数据统计</title>
<style>body{font-family:system-ui,sans-serif;background:#0b1020;color:#e6ecff;padding:28px}h1{color:#22d3ee}table{border-collapse:collapse;width:100%;margin-top:16px}td,th{border:1px solid #2a3560;padding:8px 12px;text-align:left}code{color:#8d9cc4}</style></head>
<body><h1>数据统计</h1><p>插件 <code><?= htmlspecialchars($name) ?></code> · 端口 <code><?= htmlspecialchars($port) ?></code></p>
<table><tr><th>指标</th><th>值</th></tr><tr><td>站点</td><td><?= htmlspecialchars($site) ?></td></tr><tr><td>协议</td><td><?= htmlspecialchars(getenv('NB_PLUGIN_PROTOCOL') ?: '') ?></td></tr></table>
</body></html>