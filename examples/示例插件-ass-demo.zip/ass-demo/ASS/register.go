package p_ass_demo

// register.go —— 纯声明文件：宿主只用 go/parser 读语法树，不编译、不执行。
// 下面这个类型可以根本不存在；部署机不需要安装 Go。
// 由 NebulaDrive 插件制作器生成，请勿手工改动后又在「设计」里编辑（会被覆盖）。
var Spec = PluginSpec{
    Name:            "ass-demo",
    Title:           "ASS 面板",
    Version:         "1.0.0",
    Author:          "you",
    Description:     "PHP 嵌入页面示例，声明文件放在 ASS/ 子目录",
    ProtocolVersion: 2,
    Hooks:           []string{},
    Provides:        []string{},
    Install:         []string{"plugin.json", "register.go", "co.BEGG", "in.php", "stats.php", "theme.css"},
    Runtime:         "php",
    Home:            "in.php",
}
