# 本地 AI 能力提供方

不联网的 AI Provider 示例：接管 onAIProviderResolve / onAIComplete

- 插件名：`ai-local-provider`
- 版本：`1.0.0`
- 协议：v2
- 运行时：`python`
- 目录布局：扁平（三文件与页面都在插件根目录）

## 安装

1. 把整个目录解压到 `plugins/ai-local-provider/`。
2. 后台 → 插件 → 开启**全局总开关**（需勾选风险确认）。
3. 启用 `ai-local-provider`。

> 插件默认关闭，这是刻意设计。

## 钩子

订阅：`onAIProviderResolve`、`onAIComplete`、`onAIRequest`

有钩子订阅时宿主会拉起 `plugin.py` 做 JSON-RPC over stdio。
**部署注意**：`entry` 相对插件安装**根目录**解析，宿主用 `exec` 直接执行它。
Linux/macOS 需保留 shebang 并 `chmod +x plugin.py`；Windows 请改成 `plugin.exe`
并同步修改 `plugin.json` 的 `entry`。

## 页面

- `home`（main）→ index.html 

> `home` 一律相对 **co.BEGG 所在目录**，不要写成 `in.php` 这种带子目录前缀的路径。

## 安全提醒

宿主对 `/ext/*` **完全透传鉴权**：不校验登录态、不注入 token、不设 iframe sandbox。
插件页面必须自己做权限校验。开启插件等同于把服务器执行权限交给插件作者。
