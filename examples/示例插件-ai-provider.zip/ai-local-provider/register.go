package p_ai_local_provider

// register.go —— 纯声明文件：宿主只用 go/parser 读语法树，不编译、不执行。
// 下面这个类型可以根本不存在；部署机不需要安装 Go。
// 由 NebulaDrive 插件制作器（Python 桌面版）生成。
var Spec = PluginSpec{
    Name:            "ai-local-provider",
    Title:           "本地 AI 能力提供方",
    Version:         "1.0.0",
    Author:          "you",
    Description:     "不联网的 AI Provider 示例：接管 onAIProviderResolve / onAIComplete",
    ProtocolVersion: 2,
    Hooks:           []string{"onAIProviderResolve", "onAIComplete", "onAIRequest"},
    Provides:        []string{},
    Install:         []string{"plugin.json", "register.go", "co.BEGG", "index.html", "server.py", "plugin.py"},
    Runtime:         "python",
    Home:            "index.html",
}
