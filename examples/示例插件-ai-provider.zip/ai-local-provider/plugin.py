#!/usr/bin/env python3
# NebulaDrive 插件 JSON-RPC 2.0 over stdio 骨架
# 宿主每行发一个 JSON 请求，插件每行回一个 JSON 响应；日志必须走 stderr。
import sys, json

HOOKS = ["onAIProviderResolve", "onAIComplete", "onAIRequest"]
NAME  = "ai-local-provider"

def log(msg):
    print('[plugin] ' + msg, file=sys.stderr, flush=True)

def handle(req):
    m = req.get('method')
    if m == 'init':
        return {'ok': True, 'name': NAME, 'version': '1.0.0', 'hooks': HOOKS}
    if m == 'ping':
        return {'ok': True}
    if m == 'shutdown':
        sys.exit(0)
    if m == 'fire':
        p = req.get('params', {})
        hook, ctx = p.get('hook'), p.get('ctx', {})
        # ===== 在这里写你的业务逻辑 =====
        # 决策型：拦截上传
        if hook == 'onFileUploadBefore' and str(ctx.get('fileName','')).endswith('.exe'):
            return {'decision': 'deny', 'reason': '不允许上传可执行文件'}
        # 变换型：改写 ctx（顶层键覆盖）
        # return {'ctxPatch': {'maxStorage': 999999}}
        # 通知型：只记日志
        log('fire ' + str(hook))
        return {}
    return {'error': 'method not found'}

def main():
    for line in sys.stdin:
        line = line.strip()
        if not line: continue
        try: req = json.loads(line)
        except Exception as e:
            log('bad json: ' + str(e)); continue
        rid = req.get('id', 0)
        try: result = handle(req)
        except Exception as e:
            sys.stdout.write(json.dumps({'jsonrpc':'2.0','id':rid,'error':{'code':-32603,'message':str(e)}})+'\n'); sys.stdout.flush(); continue
        if rid:
            sys.stdout.write(json.dumps({'jsonrpc':'2.0','id':rid,'result':result}, ensure_ascii=False)+'\n'); sys.stdout.flush()

if __name__ == '__main__':
    main()