#!/usr/bin/env python3
# NebulaDrive 插件页面服务：端口由宿主通过环境变量下发。
# 宿主把 cmd.Dir 设成 co.BEGG 所在目录（BeggDir），页面文件就在这里，
# 所以直接用当前工作目录即可；不要 chdir(NB_PLUGIN_DIR)。
import os
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

PORT = int(os.environ.get("NB_PLUGIN_PORT", "0"))
HOST = os.environ.get("NB_PLUGIN_HOST", "127.0.0.1")
ROOT = os.getcwd()

class Handler(SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # 日志走 stderr，避免污染 JSON-RPC 的 stdout

if __name__ == "__main__":
    handler = partial(Handler, directory=ROOT)
    print("[plugin] serving %s on %s:%s" % (ROOT, HOST, PORT), flush=True)
    ThreadingHTTPServer((HOST, PORT), handler).serve_forever()