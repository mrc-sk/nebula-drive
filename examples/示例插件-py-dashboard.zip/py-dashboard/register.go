package p_py_dashboard

// register.go —— 纯声明文件：宿主只用 go/parser 读语法树，不编译、不执行。
// 下面这个类型可以根本不存在；部署机不需要安装 Go。
// 由 NebulaDrive 插件制作器生成，请勿手工改动后又在「设计」里编辑（会被覆盖）。
var Spec = PluginSpec{
    Name:            "py-dashboard",
    Title:           "数据看板",
    Version:         "1.0.0",
    Author:          "you",
    Description:     "Python 标准库起 HTTP 服务",
    ProtocolVersion: 2,
    Hooks:           []string{},
    Provides:        []string{},
    Install:         []string{"plugin.json", "register.go", "co.BEGG", "index.html", "server.py"},
    Runtime:         "python",
    Home:            "index.html",
}
