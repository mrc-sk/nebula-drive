#!/usr/bin/env python3
# NebulaDrive 插件页面服务：端口由宿主通过环境变量下发。
# 注意：宿主把 cmd.Dir 设成 co.BEGG 所在目录（BeggDir），页面文件就在这里，
# 所以直接用当前工作目录即可。NB_PLUGIN_DIR 指向的是插件安装根目录，
# 在 ASS/ 这类子目录布局下 chdir 过去会找不到 home 文件。
import os
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

PORT = int(os.environ.get("NB_PLUGIN_PORT", "0"))
HOST = os.environ.get("NB_PLUGIN_HOST", "127.0.0.1")
ROOT = os.getcwd()  # = co.BEGG 所在目录

class Handler(SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # 日志走 stderr，避免污染 JSON-RPC 的 stdout

if __name__ == "__main__":
    handler = partial(Handler, directory=ROOT)
    print(f"[plugin] serving {ROOT} on {HOST}:{PORT}", flush=True)
    ThreadingHTTPServer((HOST, PORT), handler).serve_forever()