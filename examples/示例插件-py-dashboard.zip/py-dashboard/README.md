# 数据看板

Python 标准库起 HTTP 服务

- 插件名：`py-dashboard`
- 版本：`1.0.0`
- 协议：v2
- 运行时：`python`（要求 python3）
- 目录布局：扁平（三文件与页面都在插件根目录）

## 安装

1. 把整个目录解压到 `plugins/py-dashboard/`。
2. 后台 → 插件 → 开启**全局总开关**（需勾选风险确认）。
3. 启用 `py-dashboard`。

> 插件默认关闭，这是刻意设计。

## 页面

- `home`（admin）→ index.html 

> `home` 一律相对 **co.BEGG 所在目录**，不要写成 `in.php` 这种带子目录前缀的路径。

## 安全提醒

宿主对 `/ext/*` **完全透传鉴权**：不校验登录态、不注入 token、不设 iframe sandbox。
插件页面必须自己做权限校验。开启插件等同于把服务器执行权限交给插件作者。
